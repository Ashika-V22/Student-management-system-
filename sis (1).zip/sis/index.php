<?php require_once('./config.php'); 
redirect('admin');
?>
